package network;

public class NetworkDataType {

	public static final byte RELIABLE=0,UNRELIABLE=1;
}

package network.packets;


public class Packet
{
	public int sequence,ack_sequence;
}
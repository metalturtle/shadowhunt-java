package scanserver;

import network.packets.Packet;

public class ScanPacket extends Packet {
	public String name;
	public boolean server;
}

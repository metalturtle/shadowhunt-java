package simulation;

import network.packets.Packet;

public class PlaceholderPacket extends Packet {
	public byte[] data;
}

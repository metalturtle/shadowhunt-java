package basic;

public class Vector2Deg extends Vector {

}

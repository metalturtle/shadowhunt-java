package basic;

public abstract class ObjectPoolCreator<T> {
	public abstract T create_object() ;
}
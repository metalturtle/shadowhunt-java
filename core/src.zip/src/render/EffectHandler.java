package render;

public class EffectHandler extends SpriteHandler
{
	EffectHandler(RenderEntityMainHandler RendEntityMainHandle)
	{
		super(RendEntityMainHandle);
	}
}

